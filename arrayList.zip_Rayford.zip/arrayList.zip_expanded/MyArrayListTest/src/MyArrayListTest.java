import static org.junit.Assert.*;

import org.junit.Test;

public class MyArrayListTest {

	@Test
	public void testConstructorAndInitialCapacity() throws Exception {
		MyArrayList<String> testArray = new MyArrayList<String>();
		assertEquals(10,testArray.getInitialCapacity());
		
		int capacity = 3;
		MyArrayList<String> testArray2 = new MyArrayList<String>(capacity);
		assertEquals(capacity,testArray2.getInitialCapacity());
	}
	
	@Test
	public void testAddGetSize() throws Exception {
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		assertEquals(0,integerArray.size());
		Integer integer = new Integer(3);
		integerArray.add(integer);
		assertEquals(1,integerArray.size());
		assertEquals(0,integerArray.indexOf(integer));
		assertSame(integer,integerArray.get(0));
		
		Integer integer2 = new Integer(6);
		integerArray.add(integer2);
		assertEquals(2,integerArray.size());
		assertEquals(1,integerArray.indexOf(integer2));
		assertSame(integer2,integerArray.get(1));
	}
	
	@Test
	public void testAdd() throws Exception {
		MyArrayList<Integer> integerArray2 = new MyArrayList<Integer>();	
		Integer integer3 = new Integer(10);
		integerArray2.add(0, integer3);
		assertEquals(0, integerArray2.indexOf(integer3));
		assertSame(integer3, integerArray2.get(0));
		
		try{
			Integer integer4 = new Integer(4);
			integerArray2.add(11, integer4);
		}catch(ArrayIndexOutOfBoundsException e){
			
		}
		
	}
	
	@Test
	public void testClear() throws Exception {
		MyArrayList<String> testArray = new MyArrayList<String>();
		String string1 = "Hello";
		testArray.add(0, string1);
		String string2 = "Bye";
		testArray.add(string2);
		testArray.clear();
		assertEquals(0, testArray.size());
	}
	
	@Test
	public void testContains() throws Exception {
		MyArrayList<String> stringArray2 = new MyArrayList<String>();
		String string3 = "Zebra";
		stringArray2.add(0, string3);
		assertEquals("Zebra", stringArray2.contains(string3));
	}
	
	@Test
	public void testRemove() throws Exception {
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer = 10;
		integerArray.add(0, integer);
		integerArray.remove(0);
		assertSame(null, integerArray.get(0));
		
		integerArray.isEmpty();
		assertEquals(0, integerArray.size());
		
	}
	
	@Test
	public void testSet() throws Exception {
		MyArrayList<String> stringArray = new MyArrayList<String>();
		String string1 = "dog";
		String string2 = "cat";
		String string3 = "fish";
		stringArray.add(0, string1);
		stringArray.add(1, string2);
		stringArray.add(2, string3);
		stringArray.set(2, "lizard");
		assertEquals("lizard", stringArray.get(2));
		}
	
	@Test
	public void testEnsureCapacity() throws Exception {
		
	}
	
}
