
public class MyArrayList<T> {

	private int initialCapacity;
	private Object[] array; 
	
	public MyArrayList(int initialCapacity){
		this.initialCapacity = initialCapacity;
		this.array = new Object[this.initialCapacity];
	}
	
	public MyArrayList(){
		this(10);
	}
	
	public int getInitialCapacity(){
		return this.initialCapacity;
	}
	
	public int size(){
		return 0;
	}
	
	public boolean add(T element) {
		return true;
	}
	
	public int indexOf(Object o) {
		return -1;
	}
	
	public T get(int index) {
		
	}
	
	public void clear() {
		
	}
	
	public boolean isEmpty() {
		return false;
	}
	
	public boolean contains(Object o) {
		return false;
	}
	
	public void add(int index, E element) {
		
	}
	
	public void set(int index, E element) {
		
	}
	
	public boolean remove(Object o) {
		return false;
	}
	
	public void remove(int index) {
		
	}
	
	public void ensureCapacity() {
		
		
	}
}
