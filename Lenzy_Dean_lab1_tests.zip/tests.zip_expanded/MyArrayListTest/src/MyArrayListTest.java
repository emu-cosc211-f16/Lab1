import static org.junit.Assert.*;

import org.junit.Test;

public class MyArrayListTest {

	@Test
	public void testConstructorAndInitialCapacity() throws Exception {
		MyArrayList<String> testArray = new MyArrayList<String>();
		assertEquals(10,testArray.getInitialCapacity());
		
		int capacity = 3;
		MyArrayList<String> testArray2 = new MyArrayList<String>(capacity);
		assertEquals(capacity,testArray2.getInitialCapacity());
	}
	
	@Test
	public void testAddGetSize() throws Exception {
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		assertEquals(0,integerArray.size());
		Integer integer = new Integer(3);
		integerArray.add(integer);
		assertEquals(1,integerArray.size());
		assertEquals(0,integerArray.indexOf(integer));
		assertSame(integer,integerArray.get(0));
		
		Integer integer2 = new Integer(6);
		integerArray.add(integer2);
		assertEquals(2,integerArray.size());
		assertEquals(1,integerArray.indexOf(integer2));
		assertSame(integer2,integerArray.get(1));
	}
	
	@Test
	public void testClearAndIsEmpty() throws Exception {
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer = new Integer(3);
		integerArray.add(integer);
		assertEquals(0,integerArray.indexOf(integer));
		assertEquals(1,integerArray.size());
		integerArray.clear();
		assertEquals(0,integerArray.size());
		assertTrue(integerArray.isEmpty());
		//should test for the false case of isEmpty
	}
	
	@Test
	public void testAddContains() throws Exception {
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer = new Integer(3);
		Integer integer2 = new Integer(4);
		try { 
			integerArray.add(4,integer);
			fail("Should cause index out of bounds exception, but it doesn't so nice job");
			
		} catch (IndexOutOfBoundsException e) {
			
		}
		assertFalse(integerArray.contains(integer));	
		
		integerArray.add(0,integer);
		integerArray.add(integer2);
		assertEquals(2, integerArray.size());
		assertEquals(1, integerArray.indexOf(integer));
		assertTrue(integerArray.contains(integer));
		
		
		Integer integer3 = new Integer(4);
		integerArray.add(-4,integer3);
		assertFalse(integerArray.contains(integer3));
		assertEquals(2, integerArray.size());
		
	}
	
	@Test
	public void testRemoveSet() throws Exception {
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer = new Integer(3);
		Integer integer2 = new Integer(4);
		
		integerArray.add(integer2);
		integerArray.set(0, integer);
		assertFalse(integerArray.contains(integer2));
		assertEquals(0, integerArray.indexOf(integer));
		integerArray.remove(0);
		assertFalse(integerArray.contains(integer));
		
		
		
		integerArray.add(integer);
		integerArray.add(integer);
		integerArray.set(0, integer2);
		assertEquals(2, integerArray.indexOf(integer));
		integerArray.remove(integer2);
		assertFalse(integerArray.contains(integer2));		
	}
	
	@Test
	public void testEnsureCapacity() throws Exception {
		
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>(3);
		Integer integer = new Integer(3);
		integerArray.add(integer);
		Integer integer2 = new Integer(4);
		integerArray.add(integer2);
		Integer integer3 = new Integer(3);
		integerArray.add(integer3);
		Integer integer4 = new Integer(4);
		
		
		assertEquals(3, integerArray.size());
		
		integerArray.add(integer4);
		assertTrue(integerArray.contains(integer4));
		assertEquals(4, integerArray.size());
		Integer integer5 = new Integer(4);
		integerArray.add(integer5);
		Integer integer6 = new Integer(4);
		integerArray.add(integer6);
		
		assertTrue(integerArray.contains(integer5));
		assertTrue(integerArray.contains(integer6));
		
		
		
	}
	
}
