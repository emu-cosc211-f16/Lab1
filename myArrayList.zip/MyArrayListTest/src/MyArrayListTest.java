import static org.junit.Assert.*;

import org.junit.Test;

public class MyArrayListTest {

	@Test
	public void testConstructorAndInitialCapacity() throws Exception {
		MyArrayList<String> testArray = new MyArrayList<String>();
		assertEquals(10,testArray.getInitialCapacity());
		
		int capacity = 3;
		MyArrayList<String> testArray2 = new MyArrayList<String>(capacity);
		assertEquals(capacity,testArray2.getInitialCapacity());
	}
	
	@Test
	public void testAddGetSize() throws Exception {
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		assertEquals(0,integerArray.size());
		Integer integer = new Integer(3);
		integerArray.add(integer);
		assertEquals(1,integerArray.size());
		assertEquals(0,integerArray.indexOf(integer));
		assertSame(integer,integerArray.get(0));
		
		Integer integer2 = new Integer(6);
		integerArray.add(integer2);
		assertEquals(2,integerArray.size());
		assertEquals(1,integerArray.indexOf(integer2));
		assertSame(integer2,integerArray.get(1));
		
	}
	
}
