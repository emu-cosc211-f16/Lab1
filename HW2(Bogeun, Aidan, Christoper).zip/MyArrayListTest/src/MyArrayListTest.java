import static org.junit.Assert.*;

import org.junit.Test;

public class MyArrayListTest {

	@Test
	public void testConstructorAndInitialCapacity() throws Exception {
		MyArrayList<String> testArray = new MyArrayList<String>();
		assertEquals(10,testArray.getInitialCapacity());
		
		int capacity = 3;
		MyArrayList<String> testArray2 = new MyArrayList<String>(capacity);
		assertEquals(capacity,testArray2.getInitialCapacity());
	}
	
	@Test
	public void testAddGetSize() throws Exception {
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		assertEquals(0,integerArray.size());
		Integer integer = new Integer(3);
		integerArray.add(integer);
		assertEquals(0,integerArray.indexOf(integer));
		assertSame(integer,integerArray.get(0));
		
		Integer integer2 = new Integer(6);
		integerArray.add(integer2);
		assertEquals(2,integerArray.size());
		assertEquals(1, integerArray.indexOf(integer2));
		assertSame(integer, integerArray.get(1));
	}
	
	@Test
	public void testAddIndex() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		
		Integer integer = new Integer(1);
		integerArray.add(0,integer);
		assertEquals(1,integerArray.size());
		assertEquals(0, integerArray.indexOf(integer));
		assertSame(integer, integerArray.get(0));
		
		Integer integer2 = new Integer(6);
		integerArray.add(0,integer2);
		assertEquals(2,integerArray.size());
		assertEquals(0, integerArray.indexOf(integer2));
		assertEquals(1, integerArray.indexOf(integer));		
		assertSame(integer2, integerArray.get(0));
		assertSame(integer, integerArray.get(1));
		
		Integer integer3 = new Integer (5);
		try{		
			integerArray.add(3,integer3);
			fail("Missed index of bound error");
			}catch (IndexOutOfBoundsException e){}
		assertEquals(2,integerArray.size());
		
		try{		
			integerArray.add(-2,integer3);
			fail("Index of negative number error");
			}catch (IndexOutOfBoundsException e){}
		assertEquals(2,integerArray.size());
	}
	
	@Test 
	public void testClear() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer2 = new Integer(6);
		Integer integer3 = new Integer(47);
		integerArray.add(0,integer3); 
		integerArray.add(1,integer2); 
		integerArray.clear();
		assertFalse(integerArray.contains(integer2));
		assertFalse(integerArray.contains(integer3));
		assertTrue(integerArray.isEmpty());
		assertEquals(0, integerArray.size());
	}
	
	@Test
	public void testContains() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
				Integer integer = new Integer(47);
				Integer integer2 = new Integer(64);
				integerArray.add(0, integer);
				assertTrue(integerArray.contains(integer));
				assertFalse(integerArray.contains(integer2));
	}
	
	@Test
	public void testEnsureCapacity() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>(2);
			Integer integer = new Integer(47);
			Integer integer2 = new Integer(64);
			Integer integer3 = new Integer(53);
			Integer integer4 = new Integer(23);
			
			integerArray.add(integer);
			integerArray.add(integer2);
			
			integerArray.add(integer3);
			assertTrue(integerArray.contains(integer3));
			assertEquals(2, integerArray.indexOf(integer3));
			assertEquals(3, integerArray.size());
			assertSame(integer3, integerArray.get(2));
			integerArray.add(integer4);
			assertTrue(integerArray.contains(integer4));
			assertEquals(3, integerArray.indexOf(integer4));
			assertEquals(4, integerArray.size());
			assertSame(integer4, integerArray.get(3));
	}
	
	@Test
	public void testGet() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer = new Integer(47);
		Integer integer2 = new Integer(64);
		integerArray.add(0,integer);
		integerArray.add(1,integer2);
		assertSame(integer, integerArray.get(0));
		assertSame(integer2, integerArray.get(1));
		
		try{
			integerArray.get(5);
			fail("Missed index of bound error");
			
			}catch (IndexOutOfBoundsException e){}
		assertEquals(2, integerArray.size());
		
		try{
			integerArray.get(-2);
			fail("Index of negative number error");
			
			}catch (IndexOutOfBoundsException e){}
		assertEquals(2, integerArray.size());
	}
	
	@Test
	public void testIndexOf() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer = new Integer(47);
		Integer integer2 = new Integer(64);
		Integer integer3 = new Integer(23);
		integerArray.add(0,integer);
		integerArray.add(integer2);
		assertEquals(0, integerArray.indexOf(integer));
		assertEquals(1, integerArray.indexOf(integer2));
		assertEquals(-1, integerArray.indexOf(integer3));
	}
	
	@Test
	public void testIsEmpty() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer = new Integer(47);		
		assertTrue(integerArray.isEmpty());
		integerArray.add(integer);
		assertFalse(integerArray.isEmpty());
	}
	
	@Test
	public void testRemove() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer = new Integer(3);
		Integer integer2 = new Integer(4);
		Integer integer3 = new Integer(5);

		integerArray.add(0,integer);
		integerArray.add(1,integer2);
		assertEquals(2, integerArray.size());
		assertTrue(integerArray.remove(integer));
		assertEquals(0, integerArray.indexOf(integer2));
		assertFalse(integerArray.remove(integer3));
		assertEquals(1, integerArray.size());
		
		try{		
			integerArray.remove(5);
			fail("Missed index of bound error");
			
			}catch (IndexOutOfBoundsException e){}
		assertEquals(1, integerArray.size());
		
		try{		
			integerArray.remove(-2);
			fail("Index of negative number error");
			
			}catch (IndexOutOfBoundsException e){}
		assertEquals(1, integerArray.size());
		
		integerArray.remove(0);
		assertEquals(0, integerArray.size());
		
	}
	
	@Test
	public void testSet() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		Integer integer = new Integer(3);
		Integer integer2 = new Integer(4);
		Integer integer3 = new Integer(5);
		Integer integer4 = new Integer(43);
		
		integerArray.add(0,integer);
		integerArray.add(1,integer2);
		integerArray.set(1, integer3);
		assertEquals(1, integerArray.indexOf(integer3));
		assertEquals(2, integerArray.size());
		assertSame(integer3, integerArray.get(1));
		
		try{		
			integerArray.set(5,integer4);
			fail("Missed index of bound error");
			
			}catch (IndexOutOfBoundsException e){}
		assertEquals(2, integerArray.size());
		
		try{		
			integerArray.set(-2,integer4);
			fail("Index of negative number error");
			
			}catch (IndexOutOfBoundsException e){}
		assertEquals(2, integerArray.size());
	}
	
	/*
	@Test
	public void testSize() throws Exception{
		MyArrayList<Integer> integerArray = new MyArrayList<Integer>();
		integerArray.add(new Integer(3));
		integerArray.add(new Integer(4));
		assertEquals(2, integerArray.size());
	}
	*/
}
