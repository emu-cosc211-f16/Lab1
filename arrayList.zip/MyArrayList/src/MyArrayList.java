
public class MyArrayList<T> {

	private int initialCapacity;
	private Object[] array; 
	
	public MyArrayList(int initialCapacity){
		this.initialCapacity = initialCapacity;
		this.array = new Object[this.initialCapacity];
	}
	
	public MyArrayList(){
		this(10);
	}
	
	public int getInitialCapacity(){
		return this.initialCapacity;
	}
	
	public int size(){
		return 0;
	}
	
}
